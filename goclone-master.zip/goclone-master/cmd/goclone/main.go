package main

import "github.com/imthaghost/goclone/cmd"

func main() {
	cmd.Execute()
}
